
import type { AIProvider } from "./provider.ts";
import { RESOURCE_OVERVIEW_PROMPT } from "./prompts.ts";
import {
  validateResourceOverview,
  type ResourceOverview,
} from "./schemas.ts";

export type ResourceAnalysisResult = {
  overview: ResourceOverview;
  provider: string;
  model: string;
};

export async function analyzeResource(
  provider: AIProvider,
  title: string,
  content: string
): Promise<ResourceAnalysisResult> {
  if (!content.trim()) {
    throw new Error("Resource content cannot be empty.");
  }

  const response = await provider.generate({
    messages: [
      {
        role: "system",
        content: RESOURCE_OVERVIEW_PROMPT,
      },
      {
        role: "user",
        content: `Analyse the following resource.

Title: ${title}

Resource content:
${content}`,
      },
    ],
    temperature: 0.2,
    maxTokens: 6000,
  });

  let parsedResponse: unknown;

  try {
    parsedResponse = JSON.parse(response.text);
  } catch {
    throw new Error("AI returned an invalid JSON response.");
  }

  const overview = validateResourceOverview(parsedResponse);

  return {
    overview,
    provider: response.provider,
    model: response.model,
  };
}
