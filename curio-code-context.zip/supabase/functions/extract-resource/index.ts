
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const MAX_CONTENT_LENGTH = 100_000;
const MAX_REDIRECTS = 5;

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
    },
  });
}

function validatePublicUrl(value: string): URL {
  const url = new URL(value);

  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("Only HTTP and HTTPS URLs are supported.");
  }

  const hostname = url.hostname.toLowerCase();

  if (
    hostname === "localhost" ||
    hostname.endsWith(".localhost") ||
    hostname.endsWith(".local") ||
    hostname === "0.0.0.0" ||
    hostname === "::1" ||
    hostname.startsWith("127.") ||
    hostname.startsWith("10.") ||
    hostname.startsWith("192.168.") ||
    hostname.startsWith("169.254.") ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(hostname)
  ) {
    throw new Error("This URL is not publicly accessible.");
  }

  return url;
}

async function fetchPage(initialUrl: string): Promise<Response> {
  let currentUrl = validatePublicUrl(initialUrl);

  for (let attempt = 0; attempt <= MAX_REDIRECTS; attempt++) {
    const response = await fetch(currentUrl.toString(), {
      method: "GET",
      redirect: "manual",
      signal: AbortSignal.timeout(20_000),
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; CurioBot/1.0; +https://curio.app)",
        Accept: "text/html, text/plain;q=0.9",
      },
    });

    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");

      if (!location) {
        throw new Error("The webpage redirected without a destination.");
      }

      if (attempt === MAX_REDIRECTS) {
        throw new Error("Too many redirects while fetching the webpage.");
      }

      currentUrl = validatePublicUrl(
        new URL(location, currentUrl).toString(),
      );

      continue;
    }

    return response;
  }

  throw new Error("Could not fetch the webpage.");
}

function decodeHtmlEntities(text: string): string {
  const namedEntities: Record<string, string> = {
    amp: "&",
    quot: '"',
    apos: "'",
    lt: "<",
    gt: ">",
    nbsp: " ",
    rsquo: "'",
    lsquo: "'",
    rdquo: '"',
    ldquo: '"',
    ndash: "–",
    mdash: "—",
    hellip: "…",
    copy: "©",
    reg: "®",
  };

  return text
    .replace(/&#(\d+);/g, (_, code) =>
      String.fromCodePoint(Number(code))
    )
    .replace(/&#x([0-9a-f]+);/gi, (_, code) =>
      String.fromCodePoint(parseInt(code, 16))
    )
    .replace(/&([a-z]+);/gi, (match, entity) =>
      namedEntities[entity.toLowerCase()] ?? match
    );
}

function extractReadableText(html: string): string {
  let content = html;

  // Remove elements that usually do not contain useful article content.
  content = content.replace(
    /<(script|style|noscript|svg|nav|footer|header|aside|form|iframe)[^>]*>[\s\S]*?<\/\1>/gi,
    " ",
  );

  content = content.replace(/<!--[\s\S]*?-->/g, " ");

  // Prefer the article or main content when available.
  const articleMatch = content.match(
    /<article\b[^>]*>([\s\S]*?)<\/article>/i,
  );

  const mainMatch = content.match(
    /<main\b[^>]*>([\s\S]*?)<\/main>/i,
  );

  if (articleMatch?.[1]) {
    content = articleMatch[1];
  } else if (mainMatch?.[1]) {
    content = mainMatch[1];
  }

  // Preserve paragraph and heading boundaries.
  content = content.replace(
    /<\/(p|div|h[1-6]|li|section|br|blockquote|tr)>/gi,
    "\n",
  );

  content = content.replace(/<[^>]+>/g, " ");
  content = decodeHtmlEntities(content);

  return content
    .replace(/\r/g, "\n")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n\s*\n+/g, "\n\n")
    .trim()
    .slice(0, MAX_CONTENT_LENGTH);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed." }, 405);
  }

  let resourceId: string | null = null;
  let userId: string | null = null;
  let adminClient: ReturnType<typeof createClient> | null = null;

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      throw new Error("Supabase environment variables are missing.");
    }

    const authorization = req.headers.get("Authorization");

    if (!authorization) {
      return jsonResponse({ error: "Authorization required." }, 401);
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: {
        headers: { Authorization: authorization },
      },
    });

    const {
      data: { user },
      error: authError,
    } = await userClient.auth.getUser();

    if (authError || !user) {
      return jsonResponse({ error: "Invalid or expired session." }, 401);
    }

    userId = user.id;

    const body = await req.json();
    resourceId = body.resource_id;

    if (
      typeof resourceId !== "string" ||
      !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        resourceId,
      )
    ) {
      return jsonResponse({ error: "A valid resource_id is required." }, 400);
    }

    adminClient = createClient(supabaseUrl, serviceRoleKey);

    // Verify that this resource belongs to the authenticated user.
    const { data: resource, error: resourceError } = await adminClient
      .from("resources")
      .select("id, source_url")
      .eq("id", resourceId)
      .eq("user_id", userId)
      .single();

    if (resourceError || !resource) {
      return jsonResponse({ error: "Resource not found." }, 404);
    }

    if (!resource.source_url) {
      return jsonResponse(
        { error: "This resource does not have a source URL." },
        400,
      );
    }

    await adminClient
      .from("resources")
      .update({ extraction_status: "processing" })
      .eq("id", resourceId)
      .eq("user_id", userId);

    // Fetch the webpage.
    const response = await fetchPage(resource.source_url);

    if (!response.ok) {
      throw new Error(
        `The webpage returned HTTP ${response.status}.`,
      );
    }

    const contentType = response.headers.get("content-type") ?? "";

    if (
      !contentType.includes("text/html") &&
      !contentType.includes("text/plain")
    ) {
      throw new Error(
        `Unsupported webpage content type: ${contentType || "unknown"}.`,
      );
    }

    const pageContent = await response.text();

    if (!pageContent.trim()) {
      throw new Error("The webpage returned empty content.");
    }

    const extractedText = contentType.includes("text/plain")
      ? pageContent.trim().slice(0, MAX_CONTENT_LENGTH)
      : extractReadableText(pageContent);

    if (extractedText.length < 100) {
      throw new Error(
        "Not enough readable text could be extracted from this webpage.",
      );
    }

    // Check whether content already exists for this resource.
    const { data: existingContent, error: contentLookupError } =
      await adminClient
        .from("resource_contents")
        .select("id, content_version")
        .eq("resource_id", resourceId)
        .eq("user_id", userId)
        .maybeSingle();

    if (contentLookupError) {
      throw new Error(
        `Could not check existing resource content: ${contentLookupError.message}`,
      );
    }

    const contentVersion = existingContent
      ? (existingContent.content_version ?? 0) + 1
      : 1;

    if (existingContent) {
      const { error: updateError } = await adminClient
        .from("resource_contents")
        .update({
          content_text: extractedText,
          content_source: "url_extraction",
          content_version: contentVersion,
        })
        .eq("id", existingContent.id)
        .eq("user_id", userId);

      if (updateError) {
        throw new Error(
          `Could not save extracted content: ${updateError.message}`,
        );
      }
    } else {
      const { error: insertError } = await adminClient
        .from("resource_contents")
        .insert({
          resource_id: resourceId,
          user_id: userId,
          content_text: extractedText,
          content_source: "url_extraction",
          content_version: contentVersion,
        });

      if (insertError) {
        throw new Error(
          `Could not save extracted content: ${insertError.message}`,
        );
      }
    }

    const { error: statusError } = await adminClient
      .from("resources")
      .update({ extraction_status: "completed" })
      .eq("id", resourceId)
      .eq("user_id", userId);

    if (statusError) {
      throw new Error(
        `Content was saved, but extraction status could not be updated: ${statusError.message}`,
      );
    }

    return jsonResponse({
      success: true,
      resource_id: resourceId,
      extracted_characters: extractedText.length,
      content_version: contentVersion,
      extraction_status: "completed",
    });
  } catch (error) {
    const message = error instanceof Error
      ? error.message
      : "An unexpected extraction error occurred.";

    console.error("Resource extraction failed:", message);

    if (adminClient && resourceId && userId) {
      await adminClient
        .from("resources")
        .update({ extraction_status: "failed" })
        .eq("id", resourceId)
        .eq("user_id", userId);
    }

    return jsonResponse({ success: false, error: message }, 500);
  }
});
