
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.8";

import { GeminiProvider } from "../_shared/ai/gemini-provider.ts";
import { analyzeResource } from "../_shared/ai/resource-analysis.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};
addEventListener("beforeunload", (event) => {
  console.log("FUNCTION SHUTDOWN REASON:", event.detail?.reason);
});
function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
    },
  });
}

async function createFingerprint(
  title: string,
  content: string
): Promise<string> {
  const input = new TextEncoder().encode(`${title}\n${content}`);
  const digest = await crypto.subtle.digest("SHA-256", input);

  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

async function processResourceInBackground(
  adminClient: ReturnType<typeof createClient>,
  resourceId: string,
  userId: string,
  title: string,
  content: string
): Promise<void> {
  try {
    console.log("Background AI analysis started.", {
      resourceId,
      contentLength: content.length,
    });

    const provider = new GeminiProvider();
    const startedAt = Date.now();

    const result = await analyzeResource(provider, title, content);

    console.log("AI analysis returned.", {
      resourceId,
      durationMs: Date.now() - startedAt,
      provider: result.provider,
      model: result.model,
    });

    // Verify that every evidence excerpt exists in the original content.
    const invalidEvidence = result.overview.evidence.some(
      (item) => !content.includes(item.sourceExcerpt)
    );

    if (invalidEvidence) {
      throw new Error(
        "AI returned evidence that could not be verified against the source."
      );
    }

    // Generate the input fingerprint.
    const inputFingerprint = await createFingerprint(title, content);

    // Save the AI output.
    const { data: savedOutput, error: saveError } = await adminClient
      .from("ai_outputs")
      .insert({
        user_id: userId,
        feature_type: "overview",
        output_data: result.overview,
        input_fingerprint: inputFingerprint,
        model_provider: result.provider,
        model_name: result.model,
        prompt_version: "resource-overview-v1",
        output_schema_version: "1",
      })
      .select("id")
      .single();

    if (saveError || !savedOutput) {
      console.error("AI output save failed:", saveError);
      throw new Error("Could not save the AI output.");
    }

    // Link the output to its resource.
    const { error: linkError } = await adminClient
      .from("ai_output_resources")
      .insert({
        output_id: savedOutput.id,
        resource_id: resourceId,
        user_id: userId,
      });

    if (linkError) {
      await adminClient
        .from("ai_outputs")
        .delete()
        .eq("id", savedOutput.id)
        .eq("user_id", userId);

      throw new Error("Could not link the AI output to its resource.");
    }

    // Mark analysis as completed.
    const { error: statusError } = await adminClient
      .from("resources")
      .update({ ai_analysis_status: "completed" })
      .eq("id", resourceId)
      .eq("user_id", userId);

    if (statusError) {
      throw new Error("Could not mark resource analysis as completed.");
    }

    console.log("Background resource processing completed.", {
      resourceId,
      outputId: savedOutput.id,
    });
  } catch (error) {
    console.error("Background resource processing failed:", {
      resourceId,
      error: error instanceof Error ? error.message : error,
    });

    const { error: statusError } = await adminClient
      .from("resources")
      .update({ ai_analysis_status: "failed" })
      .eq("id", resourceId)
      .eq("user_id", userId);

    if (statusError) {
      console.error("Could not mark analysis as failed:", statusError);
    }
  }
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return jsonResponse({
      error: {
        code: "METHOD_NOT_ALLOWED",
        message: "Method not allowed.",
      },
    }, 405);
  }

  try {
    // 1. Authenticate the user.
    console.log("Step 1: Authenticating user.");

    const authHeader = req.headers.get("Authorization");

    if (!authHeader?.startsWith("Bearer ")) {
      return jsonResponse({
        error: {
          code: "UNAUTHORIZED",
          message: "Authentication required.",
        },
      }, 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      return jsonResponse({
        error: {
          code: "SERVER_CONFIG_ERROR",
          message: "Server configuration is incomplete.",
        },
      }, 500);
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: {
        headers: {
          Authorization: authHeader,
        },
      },
    });

    const {
      data: { user },
      error: authError,
    } = await userClient.auth.getUser();

    if (authError || !user) {
      return jsonResponse({
        error: {
          code: "UNAUTHORIZED",
          message: "Invalid or expired session.",
        },
      }, 401);
    }

    // 2. Validate the request.
    console.log("Step 2: Validating request.");

    let body: Record<string, unknown>;

    try {
      body = await req.json();
    } catch {
      return jsonResponse({
        error: {
          code: "INVALID_JSON",
          message: "Request body must be valid JSON.",
        },
      }, 400);
    }

    const resourceId = body?.resource_id;

    if (typeof resourceId !== "string") {
      return jsonResponse({
        error: {
          code: "INVALID_RESOURCE_ID",
          message: "A resource_id is required.",
        },
      }, 400);
    }

    // 3. Verify resource ownership.
    console.log("Step 3: Checking resource ownership.");

    const { data: resource, error: resourceError } = await userClient
      .from("resources")
      .select("id, title, user_id")
      .eq("id", resourceId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (resourceError || !resource) {
      return jsonResponse({
        error: {
          code: "RESOURCE_NOT_FOUND",
          message: "Resource not found.",
        },
      }, 404);
    }

    // 4. Fetch saved content.
    console.log("Step 4: Fetching resource content.");

    const { data: resourceContent, error: contentError } = await userClient
      .from("resource_contents")
      .select("content_text")
      .eq("resource_id", resourceId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (contentError || !resourceContent?.content_text?.trim()) {
      return jsonResponse({
        error: {
          code: "CONTENT_NOT_FOUND",
          message: "No usable resource content was found.",
        },
      }, 404);
    }

    // 5. Create the admin client.
    console.log("Step 5: Creating admin client.");

    const adminClient = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // 6. Mark analysis as processing.
    const { error: processingStatusError } = await adminClient
      .from("resources")
      .update({ ai_analysis_status: "processing" })
      .eq("id", resourceId)
      .eq("user_id", user.id);

    if (processingStatusError) {
      throw new Error("Could not update resource processing status.");
    }

    // 7. Start AI analysis in the background.
    console.log("Step 7: Scheduling background AI analysis.", {
      resourceId,
    });

    EdgeRuntime.waitUntil(
      processResourceInBackground(
        adminClient,
        resourceId,
        user.id,
        resource.title,
        resourceContent.content_text
      )
    );

    // Return immediately without waiting for Gemini.
    return jsonResponse({
      success: true,
      resource_id: resourceId,
      status: "processing",
      message: "Resource analysis has started.",
    }, 202);

  } catch (error) {
    console.error("Resource processing request failed:", error);

    return jsonResponse({
      error: {
        code: "PROCESSING_FAILED",
        message: error instanceof Error
          ? error.message
          : "Resource processing could not be started.",
      },
    }, 500);
  }
});
