
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.8";

import { GeminiProvider } from "../_shared/ai/gemini-provider.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const QUESTION_COUNT = 5;
const OPTIONS_PER_QUESTION = 4;
const PROMPT_VERSION = "resource-quiz-v1";
const SCHEMA_VERSION = "1";

type QuizQuestion = {
  id: string;
  question: string;
  options: {
    id: string;
    text: string;
  }[];
};

type QuizAnswer = {
  correctOptionId: string;
  explanation: string;
};

type GeneratedQuiz = {
  questions: QuizQuestion[];
  answerKey: Record<string, QuizAnswer>;
};

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
    },
  });
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return (
    value !== null &&
    typeof value === "object" &&
    !Array.isArray(value)
  );
}

function validateGeneratedQuiz(data: unknown): GeneratedQuiz {
  if (!isRecord(data)) {
    throw new Error("Quiz response must be a JSON object.");
  }

  const questions = data.questions;
  const answerKey = data.answerKey;

  if (!Array.isArray(questions) || questions.length !== QUESTION_COUNT) {
    throw new Error("Quiz must contain exactly five questions.");
  }

  if (!isRecord(answerKey)) {
    throw new Error("Quiz answer key must be an object.");
  }

  const questionIds = new Set<string>();
  const sanitizedQuestions: QuizQuestion[] = [];

  for (const question of questions) {
    if (!isRecord(question)) {
      throw new Error("Invalid question structure.");
    }

    if (
      typeof question.id !== "string" ||
      !question.id.trim() ||
      typeof question.question !== "string" ||
      !question.question.trim() ||
      !Array.isArray(question.options) ||
      question.options.length !== OPTIONS_PER_QUESTION
    ) {
      throw new Error("A question has an invalid structure.");
    }

    if (questionIds.has(question.id)) {
      throw new Error("Question IDs must be unique.");
    }

    questionIds.add(question.id);

    const optionIds = new Set<string>();
    const sanitizedOptions: QuizQuestion["options"] = [];

    for (const option of question.options) {
      if (
        !isRecord(option) ||
        typeof option.id !== "string" ||
        !option.id.trim() ||
        typeof option.text !== "string" ||
        !option.text.trim()
      ) {
        throw new Error("A question contains an invalid option.");
      }

      if (optionIds.has(option.id)) {
        throw new Error("Option IDs must be unique per question.");
      }

      optionIds.add(option.id);

      sanitizedOptions.push({
        id: option.id,
        text: option.text,
      });
    }

    // Only explicitly approved public fields are retained.
    sanitizedQuestions.push({
      id: question.id,
      question: question.question,
      options: sanitizedOptions,
    });
  }

  const answerIds = Object.keys(answerKey);

  if (
    answerIds.length !== QUESTION_COUNT ||
    !answerIds.every((id) => questionIds.has(id))
  ) {
    throw new Error("Answer key does not match the questions.");
  }

  const sanitizedAnswerKey: Record<string, QuizAnswer> = {};

  for (const question of sanitizedQuestions) {
    const answer = answerKey[question.id];

    if (
      !isRecord(answer) ||
      typeof answer.correctOptionId !== "string" ||
      typeof answer.explanation !== "string" ||
      !answer.explanation.trim()
    ) {
      throw new Error("An answer has an invalid structure.");
    }

    const validOption = question.options.some(
      (option) => option.id === answer.correctOptionId
    );

    if (!validOption) {
      throw new Error("An answer references an unknown option.");
    }

    sanitizedAnswerKey[question.id] = {
      correctOptionId: answer.correctOptionId,
      explanation: answer.explanation,
    };
  }

  return {
    questions: sanitizedQuestions,
    answerKey: sanitizedAnswerKey,
  };
}

async function createFingerprint(
  title: string,
  content: string,
  provider: string,
  model: string
): Promise<string> {
  const input = new TextEncoder().encode(
    [
      title,
      content,
      PROMPT_VERSION,
      SCHEMA_VERSION,
      provider,
      model,
      "temperature=0.2",
      "questions=5",
      "options=4",
    ].join("\n")
  );

  const digest = await crypto.subtle.digest("SHA-256", input);

  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

const QUIZ_SYSTEM_PROMPT = `
You are Curio, an AI-powered learning and discovery assistant.

Your task is to generate a five-question multiple-choice quiz based ONLY
on the resource provided by the user.

RULES:
1. Use only information explicitly supported by the resource.
2. Generate exactly five meaningful questions.
3. Each question must have exactly four answer options.
4. Each question must have exactly one correct answer.
5. Avoid ambiguous, repetitive, trivial or misleading questions.
6. Test understanding of important concepts, not just memorisation.
7. Use clear and accessible language.
8. Do not introduce external facts or assumptions.
9. Make incorrect options plausible but clearly incorrect according to the source.
10. Provide a concise explanation for each correct answer, grounded in the source.
11. Do not reveal the correct answer inside the question or options.
12. Do not include markdown or commentary.

OUTPUT:
Return valid JSON only, following this exact structure:

{
  "questions": [
    {
      "id": "q1",
      "question": "Question text",
      "options": [
        { "id": "a", "text": "Option A" },
        { "id": "b", "text": "Option B" },
        { "id": "c", "text": "Option C" },
        { "id": "d", "text": "Option D" }
      ]
    }
  ],
  "answerKey": {
    "q1": {
      "correctOptionId": "a",
      "explanation": "Explanation supported by the resource."
    }
  }
}

The questions array must contain exactly five questions.
The answerKey must contain exactly one entry for each question.
`;

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return jsonResponse({
      error: {
        code: "METHOD_NOT_ALLOWED",
        message: "Method not allowed.",
      },
    }, 405);
  }

  try {
    // 1. Authenticate the user.
    const authHeader = req.headers.get("Authorization");

    if (!authHeader?.startsWith("Bearer ")) {
      return jsonResponse({
        error: {
          code: "UNAUTHORIZED",
          message: "Authentication required.",
        },
      }, 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      return jsonResponse({
        error: {
          code: "SERVER_CONFIG_ERROR",
          message: "Server configuration is incomplete.",
        },
      }, 500);
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: {
        headers: {
          Authorization: authHeader,
        },
      },
    });

    const {
      data: { user },
      error: authError,
    } = await userClient.auth.getUser();

    if (authError || !user) {
      return jsonResponse({
        error: {
          code: "UNAUTHORIZED",
          message: "Invalid or expired session.",
        },
      }, 401);
    }

    // 2. Validate request.
    let body: Record<string, unknown>;

    try {
      const parsedBody: unknown = await req.json();

      if (!isRecord(parsedBody)) {
        throw new Error("Invalid request body.");
      }

      body = parsedBody;
    } catch {
      return jsonResponse({
        error: {
          code: "INVALID_JSON",
          message: "Request body must be a valid JSON object.",
        },
      }, 400);
    }

    const resourceId = body.resource_id;

    const uuidPattern =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    if (
      typeof resourceId !== "string" ||
      !uuidPattern.test(resourceId)
    ) {
      return jsonResponse({
        error: {
          code: "INVALID_RESOURCE_ID",
          message: "A valid resource_id is required.",
        },
      }, 400);
    }

    // 3. Verify resource ownership.
    const { data: resource, error: resourceError } = await userClient
      .from("resources")
      .select("id, title, user_id")
      .eq("id", resourceId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (resourceError || !resource) {
      return jsonResponse({
        error: {
          code: "RESOURCE_NOT_FOUND",
          message: "Resource not found.",
        },
      }, 404);
    }

    // 4. Fetch saved resource content.
    const { data: resourceContent, error: contentError } =
      await userClient
        .from("resource_contents")
        .select("content_text")
        .eq("resource_id", resourceId)
        .eq("user_id", user.id)
        .maybeSingle();

    if (contentError || !resourceContent?.content_text?.trim()) {
      return jsonResponse({
        error: {
          code: "CONTENT_NOT_FOUND",
          message: "No usable resource content was found.",
        },
      }, 404);
    }

    // 5. Generate quiz with Gemini.
    const provider = new GeminiProvider();

    const response = await provider.generate({
      messages: [
        {
          role: "system",
          content: QUIZ_SYSTEM_PROMPT,
        },
        {
          role: "user",
          content: `Generate a quiz from this resource.

Title: ${resource.title}

Resource content:
${resourceContent.content_text}`,
        },
      ],
      temperature: 0.2,
      maxTokens: 6000,
    });

    let parsedResponse: unknown;

    try {
      parsedResponse = JSON.parse(response.text);
    } catch {
      throw new Error("AI returned an invalid JSON response.");
    }

    const quiz = validateGeneratedQuiz(parsedResponse);

    // 6. Create fingerprint using actual provider metadata.
    const inputFingerprint = await createFingerprint(
      resource.title,
      resourceContent.content_text,
      response.provider,
      response.model
    );

    // 7. Create admin client and save quiz + attempt atomically.
    const adminClient = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const { data: savedQuiz, error: saveError } = await adminClient
      .rpc("create_quiz_with_attempt", {
        p_user_id: user.id,
        p_resource_id: resourceId,
        p_question_set: quiz.questions,
        p_answer_key: quiz.answerKey,
        p_total_questions: QUESTION_COUNT,
        p_input_fingerprint: inputFingerprint,
        p_model_provider: response.provider,
        p_model_name: response.model,
        p_prompt_version: PROMPT_VERSION,
      })
      .single();

    if (saveError || !savedQuiz) {
      console.error("Quiz save failed:", saveError);
      throw new Error("Could not save the generated quiz.");
    }

    // 8. Return questions only. Never return the answer key.
    return jsonResponse({
      success: true,
      quiz_id: savedQuiz.quiz_id,
      attempt_id: savedQuiz.attempt_id,
      questions: savedQuiz.question_set,
      total_questions: savedQuiz.total_questions,
      created: savedQuiz.created,
    }, 200);
  } catch (error) {
    console.error("Quiz generation failed:", {
      error: error instanceof Error ? error.message : "Unknown error",
    });

    return jsonResponse({
      error: {
        code: "QUIZ_GENERATION_FAILED",
        message: error instanceof Error
          ? error.message
          : "Quiz generation failed.",
      },
    }, 500);
  }
});
